import express, { Request, Response, NextFunction } from "express";
import dotenv from "dotenv";
import bodyParser from "body-parser";
import routes from "./src/routes";
import cors from "cors";
import { apiLogger } from "./src/middleware/apiLogger";
import logger from "./src/utils/logger";
import { setupSwagger } from "./src/utils/swagger";

dotenv.config();

const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Swagger documentation
setupSwagger(app);

// Apply API logger for all routes
app.use(apiLogger);

// Mount all routes at root ("/")
//  This prevents double /api prefix
app.use("/", routes);

// Health Check
app.get("/", (req: Request, res: Response) => {
  logger.info(`Health check requested from IP: ${req.ip}`);
  res.send("PLEX API is running!");
});

// Global error handler
app.use(
  (err: any, req: Request, res: Response, next: NextFunction) => {
    logger.error(`Unhandled error: ${err.message}`, err);
    res.status(500).json({ error: "Internal server error" });
  }
);

export default app;
