import dotenv from "dotenv";
dotenv.config(); // Load environment variables first

import { createServer } from "http";
import { Server } from "socket.io";
import app from "./app";
import { initDatabase } from "./src/db/database";
import logger from "./src/utils/logger";
import { initSendGrid } from "./src/utils/sendEmail";
import fs from "fs";
import path from "path";

//  Load config.json only if needed (fallback for local use)
const configPath = path.join(__dirname, "src", "config", "config.json");
const config = fs.existsSync(configPath)
  ? JSON.parse(fs.readFileSync(configPath, "utf-8"))
  : {};

//  Use Elastic Beanstalk's PORT first, then config.json, then 8080
const PORT = process.env.PORT || config.PORT || 8080;

async function startServer() {
  try {
    //  Initialize SendGrid
    initSendGrid();
    logger.info("SendGrid initialized successfully");

    //  Initialize Database
    await initDatabase();
    logger.info("Database connected and synced successfully");

    //  Create HTTP server with Express
    const httpServer = createServer(app);

    //  Initialize Socket.IO
    const io = new Server(httpServer, {
      cors: {
        origin: "*",
        methods: ["GET", "POST"],
      },
    });

    //  Socket.IO events
    io.on("connection", (socket) => {
      logger.info(`Client connected: ${socket.id}`);

      socket.on("joinBooking", (bookingId: number) => {
        socket.join(`booking_${bookingId}`);
        logger.info(`Client ${socket.id} joined booking_${bookingId}`);
      });

      socket.on(
        "updateLocation",
        (data: { bookingId: number; lat: number; lng: number }) => {
          io.to(`booking_${data.bookingId}`).emit("locationUpdate", data);
          logger.info(
            `Location update emitted for booking_${data.bookingId}: ${JSON.stringify(
              data
            )}`
          );
        }
      );

      socket.on("disconnect", () => {
        logger.info(`Client disconnected: ${socket.id}`);
      });
    });

    //  Start server on EB port (must be 0.0.0.0)
    httpServer.listen(PORT, "0.0.0.0", () => {
      logger.info(`🚀 Server running and listening on port ${PORT}`);
    });
  } catch (err: any) {
    logger.error(`Unable to start server: ${err.message}`, err);
    process.exit(1);
  }
}

startServer();
