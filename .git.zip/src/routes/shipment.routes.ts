import { Router } from "express";
import { ShipmentController } from "../controllers/shipment.controller";
import { authMiddleware } from "../middleware/auth.middleware";

const router = Router();
const controller = new ShipmentController();

/**
 * @swagger
 * tags:
 *   name: Shipment
 *   description: APIs for managing shipments, payments, and live tracking
 */

/**
 * @swagger
 * /shipments/estimate:
 *   post:
 *     summary: Estimate shipment cost using Google Distance Matrix API
 *     tags: [Shipment]
 *     parameters:
 *       - in: header
 *         name: token
 *         required: true
 *         schema:
 *           type: string
 *         description: Authentication token
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - originLat
 *               - originLng
 *               - destinationLat
 *               - destinationLng
 *               - weight
 *             properties:
 *               originLat:
 *                 type: number
 *               originLng:
 *                 type: number
 *               destinationLat:
 *                 type: number
 *               destinationLng:
 *                 type: number
 *               weight:
 *                 type: number
 *     responses:
 *       200:
 *         description: Estimated cost and distance calculated
 */
router.post("/estimate", authMiddleware(), controller.estimate.bind(controller));

/**
 * @swagger
 * /shipments/create:
 *   post:
 *     summary: Create a new shipment and initialize Stripe PaymentIntent
 *     tags: [Shipment]
 *     parameters:
 *       - in: header
 *         name: token
 *         required: true
 *         schema:
 *           type: string
 *         description: Authentication token
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - userId
 *               - originLat
 *               - originLng
 *               - destinationLat
 *               - destinationLng
 *               - weight
 *             properties:
 *               userId:
 *                 type: string
 *               originLat:
 *                 type: number
 *               originLng:
 *                 type: number
 *               destinationLat:
 *                 type: number
 *               destinationLng:
 *                 type: number
 *               weight:
 *                 type: number
 *     responses:
 *       201:
 *         description: Shipment created successfully with payment intent
 */
router.post("/create", authMiddleware(), controller.createWithPayment.bind(controller));

/**
 * @swagger
 * /shipments/confirm-payment:
 *   post:
 *     summary: Confirm paypal payment for a shipment
 *     tags: [Shipment]
 *     parameters:
 *       - in: header
 *         name: token
 *         required: true
 *         schema:
 *           type: string
 *         description: Authentication token
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - shipmentId
 *               - paymentIntentId
 *               - paymentStatus
 *             properties:
 *               shipmentId:
 *                 type: number
 *               paymentIntentId:
 *                 type: string
 *               paymentStatus:
 *                 type: string
 *     responses:
 *       200:
 *         description: Payment confirmed successfully
 */
router.post(
  "/confirm-payment",
  authMiddleware(),
  controller.confirmPayment.bind(controller)
);

/**
 * @swagger
 * /shipments/{id}/accept:
 *   post:
 *     summary: Driver accepts a shipment (assign driver + vehicle)
 *     tags: [Shipment]
 *     parameters:
 *       - in: header
 *         name: token
 *         required: true
 *         schema:
 *           type: string
 *         description: Authentication token
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Shipment ID
 *     responses:
 *       200:
 *         description: Shipment accepted successfully
 */
router.post(
  "/:id/accept",
  authMiddleware(),
  controller.acceptShipment.bind(controller)
);

/**
 * @swagger
 * /shipments/{id}/location:
 *   post:
 *     summary: Update driver's current GPS location (live tracking)
 *     tags: [Shipment]
 *     parameters:
 *       - in: header
 *         name: token
 *         required: true
 *         schema:
 *           type: string
 *         description: Authentication token
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Shipment ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - lat
 *               - lng
 *             properties:
 *               lat:
 *                 type: number
 *               lng:
 *                 type: number
 *     responses:
 *       200:
 *         description: Location updated and broadcast successfully
 */
router.post(
  "/:id/location",
  authMiddleware(),
  controller.updateLocation.bind(controller)
);

/**
 * @swagger
 * /shipments/{id}/location:
 *   get:
 *     summary: Get current shipment GPS location
 *     tags: [Shipment]
 *     parameters:
 *       - in: header
 *         name: token
 *         required: true
 *         schema:
 *           type: string
 *         description: Authentication token
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Shipment ID
 *     responses:
 *       200:
 *         description: Current location retrieved
 */
router.get(
  "/:id/location",
  authMiddleware(),
  controller.getLocation.bind(controller)
);

/**
 * @swagger
 * /shipments:
 *   get:
 *     summary: Get all shipments for current user
 *     tags: [Shipment]
 *     parameters:
 *       - in: header
 *         name: token
 *         required: true
 *         schema:
 *           type: string
 *         description: Authentication token
 *     responses:
 *       200:
 *         description: List of shipments
 */
router.get("/", authMiddleware(), controller.getAllShipments.bind(controller));

/**
 * @swagger
 * /shipments/{id}:
 *   get:
 *     summary: Get shipment details by ID
 *     tags: [Shipment]
 *     parameters:
 *       - in: header
 *         name: token
 *         required: true
 *         schema:
 *           type: string
 *         description: Authentication token
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Shipment ID
 *     responses:
 *       200:
 *         description: Shipment details retrieved
 */
router.get("/:id", authMiddleware(), controller.getShipmentById.bind(controller));

/**
 * @swagger
 * /shipments/{id}:
 *   put:
 *     summary: Update shipment details
 *     tags: [Shipment]
 *     parameters:
 *       - in: header
 *         name: token
 *         required: true
 *         schema:
 *           type: string
 *         description: Authentication token
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Shipment ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               weight:
 *                 type: number
 *               originLat:
 *                 type: number
 *               originLng:
 *                 type: number
 *               destinationLat:
 *                 type: number
 *               destinationLng:
 *                 type: number
 *     responses:
 *       200:
 *         description: Shipment updated successfully
 */
router.put("/:id", authMiddleware(), controller.updateShipment.bind(controller));

/**
 * @swagger
 * /shipments/{id}:
 *   delete:
 *     summary: Delete shipment by ID
 *     tags: [Shipment]
 *     parameters:
 *       - in: header
 *         name: token
 *         required: true
 *         schema:
 *           type: string
 *         description: Authentication token
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Shipment ID
 *     responses:
 *       200:
 *         description: Shipment deleted successfully
 */
router.delete("/:id", authMiddleware(), controller.deleteShipment.bind(controller));

export default router;
