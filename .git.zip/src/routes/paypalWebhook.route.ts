import express, { Request, Response } from 'express';
import { capturePayment } from '../services/payment.service';
import Shipment from '../models/shipment.model';

const router = express.Router();

router.post('/webhook', express.json(), async (req: Request, res: Response) => {
  try {
    const event = req.body;
    console.log('🔔 PayPal Webhook Event:', JSON.stringify(event, null, 2));

    const eventType = event.event_type;
    const resource = event.resource;

    //  Handle "ORDER APPROVED" — buyer confirmed payment
    if (eventType === 'CHECKOUT.ORDER.APPROVED') {
      const orderId = resource.id;
      console.log(` Order approved: ${orderId}`);
      await capturePayment(orderId);
    }

    //  Handle "PAYMENT COMPLETED" — actual money received
    if (eventType === 'PAYMENT.CAPTURE.COMPLETED') {
      const captureId = resource.id;
      const orderId = resource.supplementary_data?.related_ids?.order_id;

      console.log(` Payment completed for Order: ${orderId}`);

      const shipment = await Shipment.findOne({ where: { paypalOrderId: orderId } });
      if (shipment) {
        shipment.paymentStatus = 'paid';
        shipment.status = 'awaiting_driver';
        await shipment.save();
        console.log(' Shipment updated to paid');
      }
    }

    //  Handle "PAYMENT DENIED"
    if (eventType === 'PAYMENT.CAPTURE.DENIED') {
      const orderId = resource.supplementary_data?.related_ids?.order_id;
      console.log(` Payment denied for Order: ${orderId}`);

      const shipment = await Shipment.findOne({ where: { paypalOrderId: orderId } });
      if (shipment) {
        shipment.paymentStatus = 'failed';
        shipment.status = 'payment_failed';
        await shipment.save();
        console.log(' Shipment marked as failed');
      }
    }

    res.status(200).send('Webhook processed');
  } catch (err) {
    console.error('Webhook Error:', err);
    res.status(500).json({ error: err instanceof Error ? err.message : err });
  }
});

export default router;
