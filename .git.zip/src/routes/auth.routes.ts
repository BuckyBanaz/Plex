import { Router } from "express";
import {
  registerIndividual,
  registerCorporate,
  registerGuest,
  verifyOtp,
  registerDriver,
  login,
  sendOtpHandler,
  resendOtpHandler,
  refreshTokenHandler
} from "../controllers/auth.controller";

const router = Router();


/**
 * @swagger
 * tags:
 *   name: Authentication
 *   description: User registration and authentication APIs
 */

/**
 * @swagger
 * /individual:
 *   post:
 *     summary: Register an individual user (OTP-based)
 *     tags: [Authentication]
 *     parameters:
 *        - in: header
 *          name: lang_id
 *          schema:
 *            type: string
 *            required: true
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *               - email
 *               - mobile
 *               - password
 *               - deviceId
 *               - otpType
 *             properties:
 *               name:
 *                 type: string
 *               email:
 *                 type: string
 *               mobile:
 *                 type: string
 *               password:
 *                 type: string
 *               deviceId:
 *                 type: string
 *               otpType:
 *                 type: string
 *     responses:
 *       201:
 *         description: OTP sent successfully
 *       400:
 *         description: Error in registration
 */
router.post("/individual", registerIndividual);

/**
 * @swagger
 * /corporate:
 *   post:
 *     summary: Register a corporate user (OTP-based)
 *     tags: [Authentication]
 *     parameters:
 *        - in: header
 *          name: lang_id
 *          schema:
 *            type: string
 *            required: true
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *               - email
 *               - mobile
 *               - password
 *               - companyName
 *               - sector
 *               - commercialRegNo
 *               - deviceId
 *               - otpType
 *             properties:
 *               name:
 *                 type: string
 *               email:
 *                 type: string
 *               mobile:
 *                 type: string
 *               password:
 *                 type: string
 *               companyName:
 *                 type: string
 *               sector:
 *                 type: string
 *               commercialRegNo:
 *                 type: string
 *               deviceId:
 *                 type: string
 *               otpType:
 *                 type: string
 *     responses:
 *       201:
 *         description: OTP sent successfully
 *       400:
 *         description: Error in registration
 */
router.post("/corporate", registerCorporate);

/**
 * @swagger
 * /guest:
 *   post:
 *     summary: Register a guest user (OTP-based)
 *     tags: [Authentication]
 *     parameters:
 *        - in: header
 *          name: lang_id
 *          schema:
 *            type: string
 *            required: true
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *               - email
 *               - mobile
 *               - deviceId
 *               - otpType
 *             properties:
 *               name:
 *                 type: string
 *               email:
 *                 type: string
 *               mobile:
 *                 type: string
 *               deviceId:
 *                 type: string
 *               otpType:
 *                 type: string
 *     responses:
 *       201:
 *         description: OTP sent successfully
 *       400:
 *         description: Error in registration
 */
router.post("/guest", registerGuest);

/**
 * @swagger
 * /driver:
 *   post:
 *     summary: Register a driver user (OTP-based)
 *     tags: [Authentication]
 *     parameters:
 *        - in: header
 *          name: lang_id
 *          schema:
 *            type: string
 *            required: true
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *               - email
 *               - password
 *               - mobile
 *               - vehicleType
 *               - licenseNo
 *               - deviceId
 *               - otpType
 *             properties:
 *               name:
 *                 type: string
 *               email:
 *                 type: string
 *               password:
 *                 type: string
 *               mobile:
 *                 type: string
 *               vehicleType:
 *                 type: string
 *               licenseNo:
 *                 type: string
 *               deviceId:
 *                 type: string
 *               otpType:
 *                 type: string
 *     responses:
 *       201:
 *         description: OTP sent successfully
 *       400:
 *         description: Error in registration
 */
router.post("/driver", registerDriver);

/**
 * @swagger
 * /verify-otp:
 *   post:
 *     summary: Verify OTP and complete registration
 *     tags: [Authentication]
 *     parameters:
 *        - in: header
 *          name: token
 *          schema:
 *            type: string
 *            required: true
 *        - in: header
 *          name: api_key
 *          schema:
 *            type: string
 *            required: true
 *        - in: header
 *          name: lang_id
 *          schema:
 *            type: string
 *            required: true
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - keyType
 *               - keyValue
 *               - otp
 *             properties:
 *               keyType:
 *                 type: string
 *                 description: "Type of key, e.g., email or mobile"
 *               keyValue:
 *                 type: string
 *                 description: "Email or mobile number to verify"
 *               otp:
 *                 type: string
 *                 description: "One-time password"
 *     responses:
 *       200:
 *         description: OTP verified, user created, JWT token returned in header
 *       400:
 *         description: Invalid or expired OTP
 */
router.post("/verify-otp", verifyOtp);

/**
 * @swagger
 * /login:
 *   post:
 *     summary: User login endpoint
 *     tags: [Authentication]
 *     parameters:
 *        - in: header
 *          name: lang_id
 *          schema:
 *            type: string
 *            required: true
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - email
 *               - password
 *             properties:
 *               email:
 *                 type: string
 *               password:
 *                 type: string
 *     responses:
 *       200:
 *         description: Login successful, JWT token returned in header
 *       401:
 *         description: Invalid credentials
 */
router.post("/login", login);

/**
 * @swagger
 * /sms/send-otp:
 *   post:
 *     summary: Send OTP via SMS
 *     tags: [Authentication]
 *     description: Generate and send a 6-digit OTP to a user's mobile number using Twilio.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - phoneNumber
 *             properties:
 *               phoneNumber:
 *                 type: string
 *                 example: "+919876543210"
 *     responses:
 *       200:
 *         description: OTP sent successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "OTP sent successfully"
 *                 otp:
 *                   type: number
 *                   example: 123456
 *       400:
 *         description: Invalid request (missing phone number)
 *       500:
 *         description: Server error while sending OTP
 */

router.post("/send-otp", sendOtpHandler);

/**
 * @swagger
 * /resend-otp:
 *   post:
 *     summary: Resend OTP to user (email or mobile)
 *     tags: [Authentication]
 *     parameters:
 *        - in: header
 *          name: lang_id
 *          schema:
 *            type: string
 *            required: true
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - keyType
 *               - keyValue
 *             properties:
 *               keyType:
 *                 type: string
 *                 description: "Type of key (email or mobile)"
 *               keyValue:
 *                 type: string
 *                 description: "Email or mobile number"
 *     responses:
 *       200:
 *         description: OTP resent successfully
 *       400:
 *         description: Error while resending OTP
 */
router.post("/resend-otp", resendOtpHandler);

/**
 * @swagger
 * /refresh-token:
 *   post:
 *     summary: Generate a new access token using refresh token
 *     tags: [Authentication]
 *     parameters:
 *       - in: header
 *         name: token
 *         required: true
 *         description: Refresh token
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Returns new access token
 *       401:
 *         description: Invalid or expired refresh token
 */
router.post("/refresh-token", refreshTokenHandler);

/**
 * @openapi
 * /hello:
 *   get:
 *     summary: Test route
 *     responses:
 *       200:
 *         description: Returns hello
 */
router.get("/hello", (req, res) => {
  res.send("Hello Swagger!");
});

export default router;
