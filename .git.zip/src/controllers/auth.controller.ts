import { Request, Response } from "express";
import * as registrationService from "../services/auth.service";
import logger from "../utils/logger";
import sgMail from "@sendgrid/mail";
import { generateOTP, sendSms } from "../utils/sms.service";
import fs from 'fs';

const config = JSON.parse(fs.readFileSync(__dirname + "/../config/config.json", "utf-8"));


sgMail.setApiKey(config.SENDGRID_API_KEY as string);

// ==========================
// Register Individual
// ==========================
export async function registerIndividual(req: Request, res: Response) {
  try {
    const { name, email, mobile, password, deviceId, otpType } = req.body;
    const lang_id = req.headers.lang_id;
    const api_key = config.API_KEY;

    if ( !lang_id || !api_key) {
      return res.status(400).json({ message: 'city_id, lang_id & api_key are required' });
    }

    if ( lang_id !== config.LANG_ID_ENG || api_key !== config.API_KEY) {
      return res.status(400).json({ message: 'Invalid city_id, lang_id & api_key' });
    }

    if (!name || !email || !mobile || !password || !deviceId) {
      return res.status(400).json({ message: 'All fields are required' });
    }

    const { message, tempToken } = await registrationService.registerIndividual(
      name,
      email,
      mobile,
      password,
      deviceId,
      otpType
    );

    res.status(201).json({
      message,
      token: tempToken,
      api_key
    });
  } catch (err: any) {
    logger.error(`Error in registerIndividual: ${err.message}`, err);
    res.status(400).json({ error: err.message });
  }
}




// ==========================
// Register Corporate
// ==========================
export async function registerCorporate(req: Request, res: Response) {
  try {
    const data = req.body;
    const { otpType } = req.body;
    const lang_id = req.headers.lang_id;
    const api_key = config.API_KEY;

    if( !lang_id || !api_key){
      return res.status(400).json({ message : 'city_id , lang_id & api_key are required'})
    }
    if( lang_id !== config.LANG_ID_ENG || api_key !== config.API_KEY){
      return res.status(400).json({ message : 'Invalid city_id , lang_id & api_key'})
    }

    const { message, tempToken } = await registrationService.registerCorporate(data, otpType);
    res.status(201).json({ message, token: tempToken, api_key });
  } catch (err: any) {
    logger.error(`Error in registerCorporate: ${err.message}`, err);
    res.status(400).json({ error: err.message });
  }
}


// ==========================
// Register Guest
// ==========================
export async function registerGuest(req: Request, res: Response) {
  try {
    const { name, email, mobile, deviceId, otpType } = req.body;
    const lang_id = req.headers.lang_id;
    const api_key = config.API_KEY;

    if( !lang_id || !api_key){
      return res.status(400).json({ message : 'city_id , lang_id & api_key are required'})
    }
    if( lang_id !== config.LANG_ID_ENG || api_key !== config.API_KEY){
      return res.status(400).json({ message : 'Invalid city_id , lang_id & api_key'})
    }
    if (!name || (!email && !mobile && !deviceId)) {
      return res.status(400).json({ message: "All fields are required" });
    }

    const { message, tempToken } = await registrationService.registerGuest(name, email, mobile, deviceId, otpType);
    res.status(201).json({ message, token: tempToken, api_key });
  } catch (err: any) {
    logger.error(`Error in registerGuest: ${err.message}`, err);
    res.status(400).json({ error: err.message });
  }
}


// ==========================
// Register Driver
// ==========================
export async function registerDriver(req: Request, res: Response) {
  try {
    const data = req.body;
    const { otpType } = req.body;
    const lang_id = req.headers.lang_id;
    const api_key = config.API_KEY;

    if( !lang_id || !api_key){
      return res.status(400).json({ message : 'city_id , lang_id & api_key are required'})
    }
    if( lang_id !== config.LANG_ID_ENG || api_key !== config.API_KEY){
      return res.status(400).json({ message : 'Invalid city_id , lang_id & api_key'})
    }
    const { name, email, password, vehicleType, licenseNo, deviceId } = data;
    if (!name || !email || !password || !vehicleType || !licenseNo || !deviceId) {
      return res.status(400).json({ message: "All fields are required" });
    }

    const { message, tempToken } = await registrationService.registerDriver(data, otpType);
    res.status(201).json({ message, token: tempToken, api_key });
  } catch (err: any) {
    logger.error(`Error in registerDriver: ${err.message}`, err);
    res.status(400).json({ error: err.message });
  }
}


// ==========================
// Verify OTP
// ==========================
export async function verifyOtp(req: Request, res: Response) {
  try {
    const { keyType, keyValue, otp } = req.body;
    const lang_id = req.headers.lang_id;
    const api_key = req.headers.api_key;

    if( !lang_id || !api_key){
      return res.status(400).json({ message : 'city_id , lang_id & api_key are required'})
    }

    if( lang_id !== config.LANG_ID_ENG || api_key !== config.API_KEY){
      return res.status(400).json({ message : 'Invalid city_id , lang_id & api_key'})
    }

    if (!keyType || !keyValue || !otp) {
      return res.status(400).json({ message: "All fields are required" });
    }

    const { user, token } = await registrationService.verifyOtpAndCreateUser(
      keyType,
      keyValue,
      otp
    );

    // Send final token in header
    res.setHeader("token", token);

    // Send success email if email
    if (keyType === "email") {
      try {
        await sgMail.send({
          to: keyValue,
          from: config.EMAIL_FROM!,
          subject: "Verification Successful - PLEX",
          text: `Hello ${user.name || "User"}, your OTP has been successfully verified.`,
          html: `<p>Hello <strong>${user.name || "User"}</strong>,</p><p>Your OTP has been successfully verified. Welcome to <b>PLEX</b>!</p>`,
        });
        logger.info(`Success email sent to: ${keyValue}`);
      } catch (err: any) {
        logger.error(`Failed to send verification email: ${err.message}`);
      }
    }

    res.status(200).json({
      success: true,
      message: "OTP verified and user registered successfully",
      user,
    });
  } catch (err: any) {
    logger.error(`Error in verifyOtp: ${err.message}`, err);
    res.status(400).json({ success: false, error: err.message });
  }
}

// ==========================
// Login
// ==========================
export async function login(req: Request, res: Response) {
  try {
    const { email, password } = req.body;
    const lang_id = req.headers.lang_id;
    const api_key = config.API_KEY;

    if( !lang_id || !api_key){
      return res.status(400).json({ message : 'city_id , lang_id & api_key are required'})
    }

    if( lang_id !== config.LANG_ID_ENG || api_key !== config.API_KEY){
      return res.status(400).json({ message : 'Invalid city_id , lang_id & api_key'})
    }

    if (!email || !password) {
      return res.status(400).json({ message: "Email and password are required" });
    }

    const { token, user } = await registrationService.login(email, password);

    res.setHeader("token", token);

    res.status(200).json({ 
      token,
      api_key,
      user
     });
  } catch (err: any) {
    logger.error(`Login failed: ${err.message}`, err);
    res.status(401).json({ error: err.message });
  }
}


// ==========================
// SendOtp
// ==========================
export async function sendOtpHandler(req: Request, res: Response) {
  try {
    const { keyType, keyValue, name } = req.body;

    if (!keyType || !keyValue) {
      return res.status(400).json({ message: "keyType and keyValue are required" });
    }

    const key = `${keyType}:${keyValue}`;
    const otp = await generateOTP(key, keyType);

    if (keyType === "email") {
      await sgMail.send({
        to: keyValue,
        from: config.EMAIL_FROM!,
        subject: "Your OTP Code",
        text: `Hello ${name || "User"}, your OTP is ${otp}`,
      });
    } else if (keyType === "mobile") {
      await sendSms(keyValue, `Your OTP is ${otp}`);
    }

    res.status(200).json({ success: true, message: `OTP sent to your ${keyType}` });
  } catch (err: any) {
    logger.error(`Error in sendOtpHandler: ${err.message}`);
    res.status(400).json({ success: false, error: err.message });
  }
}


// ==========================
// Resend OTP
// ==========================
export async function resendOtpHandler(req: Request, res: Response) {
  try {
    const { keyType, keyValue, name } = req.body;
    const lang_id = req.headers.lang_id;
    const api_key = config.API_KEY;

    if ( !lang_id || !api_key) {
      return res.status(400).json({ message: "city_id, lang_id & api_key are required" });
    }
    if ( lang_id !== config.LANG_ID_ENG || api_key !== config.API_KEY) {
      return res.status(400).json({ message: "Invalid city_id, lang_id & api_key" });
    }

    if (!keyType || !keyValue) {
      return res.status(400).json({ message: "keyType and keyValue are required" });
    }

    const message = await registrationService.resendOtp(keyType, keyValue, name);
    res.status(200).json({ success: true, message });
  } catch (err: any) {
    logger.error(`Error in resendOtpHandler: ${err.message}`, err);
    res.status(400).json({ success: false, error: err.message });
  }
}


// ==========================
// Refresh Token
// ==========================
export async function refreshTokenHandler(req: Request, res: Response) {
  try {
    const refreshToken = req.headers["token"] as string;
    if (!refreshToken) {
      return res.status(400).json({ message: "Refresh token is required" });
    }

    const newToken = await registrationService.refreshAccessToken(refreshToken);
    res.status(200).json({ token: newToken });
  } catch (err: any) {
    logger.error(`Error in refreshTokenHandler: ${err.message}`, err);
    res.status(401).json({ error: err.message });
  }
}
