import { Request, Response } from 'express';
import { ShipmentService } from '../services/shipment.service';
import { Vehicle } from '../models';

const shipmentService = new ShipmentService();

export class ShipmentController {
  // Estimate using lat/lng + weight (Google)
  async estimate(req: Request, res: Response) {
    try {
      const { originLat, originLng, destinationLat, destinationLng, weight } = req.body;
      if ([originLat, originLng, destinationLat, destinationLng, weight].some(v => v === undefined)) {
        return res.status(400).json({ success: false, message: 'Missing parameters' });
      }
      const result = await shipmentService.estimate({ originLat, originLng, destinationLat, destinationLng, weight });
      res.status(200).json({ success: true, data: result });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }

  // Create shipment and stripe payment intent (returns clientSecret)
  async createWithPayment(req: Request, res: Response) {
    try {
      const { userId, originLat, originLng, destinationLat, destinationLng, weight } = req.body;
      if (!userId || [originLat, originLng, destinationLat, destinationLng, weight].some(v => v === undefined)) {
        return res.status(400).json({ success: false, message: 'Missing parameters' });
      }

      const { shipment, orderId, approveLink, estimate }  = await shipmentService.createWithPayment({
        userId: Number(userId),
        originLat: Number(originLat),
        originLng: Number(originLng),
        destinationLat: Number(destinationLat),
        destinationLng: Number(destinationLng),
        weight: Number(weight),
      });

      res.status(201).json({ success: true, shipment, orderId, approveLink, estimate });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }

  // After frontend confirms Stripe payment succeeded, call this to mark shipment paid
  async confirmPayment(req: Request, res: Response) {
    try {
      const { shipmentId, paymentIntentId, paymentStatus } = req.body;
      if (!shipmentId || !paymentIntentId || !paymentStatus) {
        return res.status(400).json({ success: false, message: 'Missing parameters' });
      }
      const shipment = await shipmentService.confirmPaymentAndMark(Number(shipmentId), paymentIntentId, paymentStatus);
      res.status(200).json({ success: true, shipment });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }

  // Driver accepts shipment -> assign driver & vehicle and emit socket event
 async acceptShipment(req: Request, res: Response) {
  try {
    if (!req.user || req.user.id === undefined)
      return res.status(401).json({ success: false, message: 'Unauthorized' });

    const shipmentId = Number(req.params.id);
    const driverId = Number(req.user.id);

    // Fetch vehicle assigned to driver
    const vehicle = await Vehicle.findOne({ where: { driverId } });
    if (!vehicle)
      return res.status(400).json({ success: false, message: 'Driver has no vehicle assigned' });

    const vehicleId = vehicle.id;

    const updated = await shipmentService.acceptShipment(shipmentId, driverId, vehicleId);

    // emit socket event to room
    const io = req.app.get('io');
    if (io) io.to(`shipment_${shipmentId}`).emit('shipmentAccepted', updated);

    res.status(200).json({ success: true, shipment: updated });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message });
  }
}

  // Driver posts location -> save and emit to room
  async updateLocation(req: Request, res: Response) {
    try {
      // check driver auth
      if (!req.user || req.user.id === undefined) return res.status(401).json({ success: false, message: 'Unauthorized' });

      const shipmentId = Number(req.params.id);
      const { lat, lng } = req.body;
      if (lat === undefined || lng === undefined) return res.status(400).json({ success: false, message: 'Missing lat/lng' });

      const updatedLoc = await shipmentService.updateLocation(shipmentId, { lat: Number(lat), lng: Number(lng) });

      const io = req.app.get('io');
      if (io) io.to(`shipment_${shipmentId}`).emit('locationUpdate', { lat: updatedLoc.lat, lng: updatedLoc.lng });

      res.status(200).json({ success: true, currentLocation: updatedLoc });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }

  // Get current location & status
  async getLocation(req: Request, res: Response) {
    try {
      const shipmentId = Number(req.params.id);
      const shipment = await shipmentService.getShipmentById(shipmentId);
      if (!shipment) return res.status(404).json({ success: false, message: 'Shipment not found' });

      res.status(200).json({
        success: true,
        currentLocation: shipment.currentLocation,
        status: shipment.status,
        driverId: shipment.driverId,
        vehicleId: shipment.vehicleId,
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }

  // Basic CRUD wrappers if needed...
  async getShipmentById(req: Request, res: Response) {
    try {
      const shipment = await shipmentService.getShipmentById(Number(req.params.id));
      if (!shipment) return res.status(404).json({ success: false, message: 'Shipment not found' });
      res.status(200).json({ success: true, shipment });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }

  async getAllShipments(req: Request, res: Response) {
    try {
      const list = await shipmentService.getAllShipments();
      res.status(200).json({ success: true, shipments: list });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }

  // Update shipment details (for example: update weight, origin, destination)
async updateShipment(req: Request, res: Response) {
  try {
    const shipmentId = Number(req.params.id);
    const updateData = req.body;

    const shipment = await shipmentService.getShipmentById(shipmentId);
    if (!shipment) {
      return res.status(404).json({ success: false, message: 'Shipment not found' });
    }

    await shipment.update(updateData);

    res.status(200).json({ success: true, message: 'Shipment updated successfully', shipment });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message });
  }
}

// Delete shipment
async deleteShipment(req: Request, res: Response) {
  try {
    const shipmentId = Number(req.params.id);
    const shipment = await shipmentService.getShipmentById(shipmentId);
    if (!shipment) {
      return res.status(404).json({ success: false, message: 'Shipment not found' });
    }

    await shipment.destroy();

    res.status(200).json({ success: true, message: 'Shipment deleted successfully' });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message });
  }
}

}


