declare module "@paypal/checkout-server-sdk" {
  const paypal: any;
  export default paypal;
}
