import 'express';

declare global {
  namespace Express {
    interface Request {
      user?: {
        id?: number;
        email?: string;
        userType?: string;
        vehicleId?: number;
        key?: string;
      };
    }
  }
}