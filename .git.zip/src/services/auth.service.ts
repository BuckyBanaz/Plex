// services/auth.service.ts
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import User from "../models/user.model";
import CorporateDetail from "../models/corporate.model";
import Vehicle from "../models/vehicle.model";
import TempRegistration from "../models/tempRegistration.model";
import { generateOTP, verifyOTP } from "../utils/otp.service";
import sgMail from "@sendgrid/mail";
import logger from "../utils/logger";
import { sendSms } from "../utils/sms.service";
import { UserLocation } from "../models";
import  CurrentBalance  from "../models/currentBalance.model";
import { sequelize } from "../db/database";
import fs from "fs";

const config = JSON.parse(
  fs.readFileSync(__dirname + "/../config/config.json", "utf-8")
);

const JWT_SECRET = config.JWT_SECRET || "secret123";
sgMail.setApiKey(config.SENDGRID_API_KEY as string);

// ==========================
// Helper: Normalize mobile number
// ==========================
function normalizeMobile(mobile: string) {
  let digits = mobile.replace(/\D/g, "");
  if (digits.length > 10) digits = digits.slice(-10);
  return digits;
}

// ==========================
// Send OTP
// ==========================
async function sendOtp(key: string, email?: string, name?: string, mobile?: string) {
  const otp = await generateOTP(key, email ? "email" : "mobile");
  logger.info(`[OTP Generated] Key: ${key}, OTP: ${otp}`);

  const message = `Hello ${name || "User"}, your OTP is ${otp}. It will expire in 5 minutes.`;

  if (email) {
    try {
      await sgMail.send({
        to: email,
        from: config.EMAIL_FROM!,
        subject: "Verify your account",
        text: message,
        html: `<p>${message}</p>`,
      });
      logger.info(`OTP email sent to ${email}`);
    } catch (err: any) {
      logger.error(`SendGrid Error while sending to ${email}: ${err.response?.body || err.message}`);
    }
  } else if (mobile) {
    try {
      await sendSms(mobile, message);
      logger.info(`OTP SMS sent to ${mobile}`);
    } catch (err: any) {
      logger.error(`SMS Error while sending to ${mobile}: ${err.message}`);
    }
  }

  return otp;
}

// ==========================
// Register Individual
// ==========================
export async function registerIndividual(
  name: string,
  email: string,
  mobile: string,
  password: string,
  deviceId: string,
  otpType: "email" | "mobile"
) {
  if (!name || !email || !mobile || !password || !deviceId)
    throw new Error("Name, email, password, and deviceId are required");

  const existingUser = await User.findOne({ where: { email } });
  if (existingUser) throw new Error("User already registered");

  //  Set key based on OTP type
  const key = otpType === "mobile" ? `mobile:${normalizeMobile(mobile)}` : `email:${email.toLowerCase()}`;

  const existingTemp = await TempRegistration.findOne({ where: { key } });
  if (existingTemp) await existingTemp.destroy();

  await TempRegistration.create({
    key,
    data: { name, email, mobile, password, deviceId, userType: "individual" },
    expiresAt: new Date(Date.now() + 10 * 60 * 1000),
  });

  if (otpType === "mobile") {
    await sendSms(mobile, `Your OTP is ${await generateOTP(key, "mobile")}`);
  } else {
    await sendOtp(key, email, name);
  }

  const tempToken = jwt.sign({ key, userType: "individual" }, JWT_SECRET, { expiresIn: "10m" });
  return { message: `OTP sent to your ${otpType}`, key, tempToken };
}

// ==========================
// Register Corporate
// ==========================
export async function registerCorporate(data: any, otpType: "email" | "mobile" = "email") {
  const { name, email, mobile, password, companyName, sector, commercialRegNo, deviceId } = data;

  if (!name || !email || !mobile || !password || !companyName || !sector || !commercialRegNo || !deviceId)
    throw new Error("Missing required corporate registration fields");

  const existingUser = await User.findOne({ where: { email } });
  if (existingUser) throw new Error("User already registered");

  const key = otpType === "mobile" ? `mobile:${normalizeMobile(mobile)}` : `email:${email.toLowerCase()}`;

  const existingTemp = await TempRegistration.findOne({ where: { key } });
  if (existingTemp) await existingTemp.destroy();

  await TempRegistration.create({
    key,
    data: { ...data, userType: "corporate" },
    expiresAt: new Date(Date.now() + 10 * 60 * 1000),
  });

  if (otpType === "mobile") {
    await sendSms(mobile, `Your OTP is ${await generateOTP(key, "mobile")}`);
  } else {
    await sendOtp(key, email, name);
  }

  const tempToken = jwt.sign({ key, userType: "corporate" }, JWT_SECRET, { expiresIn: "10m" });
  return { message: "OTP sent to your email/mobile", key, tempToken };
}

// ==========================
// Register Guest
// ==========================
export async function registerGuest(
  name: string,
  email: string,
  mobile: string,
  deviceId: string,
  otpType: "email" | "mobile" = "email"
) {
  if (!name || (!email && !mobile && !deviceId)) throw new Error("Name and email/mobile/deviceId required");

  const key = otpType === "mobile" ? `mobile:${normalizeMobile(mobile)}` : `email:${email.toLowerCase()}`;

  const existingTemp = await TempRegistration.findOne({ where: { key } });
  if (existingTemp) await existingTemp.destroy();

  await TempRegistration.create({
    key,
    data: { name, email, mobile, deviceId, userType: "guest" },
    expiresAt: new Date(Date.now() + 10 * 60 * 1000),
  });

  if (otpType === "mobile") {
    await sendSms(mobile, `Your OTP is ${await generateOTP(key, "mobile")}`);
  } else {
    await sendOtp(key, email, name);
  }

  const tempToken = jwt.sign({ key, userType: "guest" }, JWT_SECRET, { expiresIn: "10m" });
  return { message: "OTP sent to your email/mobile", key, tempToken };
}

// ==========================
// Register Driver
// ==========================
export async function registerDriver(input: any, otpType: "email" | "mobile" = "email") {
  const { name, email, password, mobile, vehicleType, licenseNo } = input;
  if (!name || !email || !password || !mobile || !vehicleType || !licenseNo)
    throw new Error("Missing required driver registration fields");

  const existingUser = await User.findOne({ where: { email } });
  if (existingUser) throw new Error("User already registered");

  const key = otpType === "mobile" ? `mobile:${normalizeMobile(mobile)}` : `email:${email.toLowerCase()}`;

  const existingTemp = await TempRegistration.findOne({ where: { key } });
  if (existingTemp) await existingTemp.destroy();

  await TempRegistration.create({
    key,
    data: { ...input, userType: "driver" },
    expiresAt: new Date(Date.now() + 10 * 60 * 1000),
  });

  if (otpType === "mobile") {
    await sendSms(mobile, `Your OTP is ${await generateOTP(key, "mobile")}`);
  } else {
    await sendOtp(key, email, name);
  }

  const tempToken = jwt.sign({ key, userType: "driver" }, JWT_SECRET, { expiresIn: "10m" });
  return { message: `OTP sent to your ${otpType}`, key, tempToken };
}

// ==========================
// Verify OTP & Create User
// ==========================
export async function verifyOtpAndCreateUser(
  keyType: "email" | "mobile",
  keyValue: string,
  otp: string
) {
  const t = await sequelize.transaction();

  try {
    const normalizedKey =
      keyType === "email"
        ? `email:${keyValue.toLowerCase()}`
        : `mobile:${keyValue}`;

    const tempReg = await TempRegistration.findOne({ where: { key: normalizedKey }, transaction: t });
    if (!tempReg) throw new Error("Registration data not found");

    const { data } = tempReg;

    const ok = await verifyOTP(normalizedKey, otp);
    if (!ok) throw new Error("Invalid or expired OTP");

    const hashedPassword = data.password ? await bcrypt.hash(data.password, 10) : null;

    // Create user
    const user = await User.create(
      {
        name: data.name,
        email: data.email || (keyType === "email" ? keyValue : null),
        mobile: data.mobile || (keyType === "mobile" ? keyValue : null),
        password: hashedPassword,
        userType: data.userType,
        deviceId: data.deviceId,
      },
      { transaction: t }
    );

    if (keyType === "email") user.isEmailVerified = true;
    if (keyType === "mobile") user.isMobileVerified = true;
    await user.save({ transaction: t });

    // Save extra details
    if (data.userType === "corporate") {
      await CorporateDetail.create({ userId: user.id, ...data }, { transaction: t });
    } else if (data.userType === "driver") {
      await Vehicle.create(
        { driverId: user.id, type: data.vehicleType, licenseNo: data.licenseNo },
        { transaction: t }
      );
    }

    // Add CurrentBalance
    const currentBalance = await CurrentBalance.create(
      { userId: user.id, balance: 0 },
      { transaction: t }
    );

    await tempReg.destroy({ transaction: t });

    await t.commit();

    const token = jwt.sign({ userId: user.id, userType: user.userType }, JWT_SECRET, {
      expiresIn: "7d",
    });

    // Build response
    const userResponse: any = {
      id: user.id,
      name: user.name,
      email: user.email,
      mobile: user.mobile,
      userType: user.userType,
      isEmailVerified: user.isEmailVerified,
      isMobileVerified: user.isMobileVerified,
      createdAt: user.createdAt,
      updatedAt: user.updatedAt,
    };

    if (user.userType === "driver") {
      const vehicleInfo = await Vehicle.findOne({ where: { driverId: user.id } });
      userResponse.vehicle = vehicleInfo || null;
      userResponse.currentBalance = {
        id: currentBalance.id,
        balance: currentBalance.balance,
        createdAt: currentBalance.createdAt,
        updatedAt: currentBalance.updatedAt,
      };
    }

    return { message: `${user.userType} registered successfully`, token, user: userResponse };
  } catch (err) {
    await t.rollback();
    throw err;
  }
}



// ==========================
// Login
// ==========================
export async function login(email: string, password: string) {
  if (!email || !password) throw new Error("Email and password required");

  const user = await User.findOne({
    where: { email },
    include: [{ model: UserLocation, as: "currentLocation" }],
  });
  if (!user || !user.password) throw new Error("Invalid credentials");

  const valid = await bcrypt.compare(password, user.password);
  if (!valid) throw new Error("Invalid credentials");

  const token = jwt.sign(
    { id: user.id, userType: user.userType },
    config.JWT_SECRET,
    { expiresIn: "1h" }
  );

  const userData = user.get({ plain: true });
  delete userData.password;

  const location = userData.currentLocation
    ? {
        latitude: userData.currentLocation.latitude,
        longitude: userData.currentLocation.longitude,
        accuracy: userData.currentLocation.accuracy || 0,
        heading: userData.currentLocation.heading || 0,
        speed: userData.currentLocation.speed || 0,
        recorded_at: userData.currentLocation.createdAt,
      }
    : {
        latitude: 0,
        longitude: 0,
        accuracy: 0,
        heading: 0,
        speed: 0,
        recorded_at: userData.createdAt,
      };

  const userResponse: any = {
    id: userData.id,
    name: userData.name,
    email: userData.email,
    userType: userData.userType,
    isMobileVerified: userData.isMobileVerified,
    isEmailVerified: userData.isEmailVerified,
    createdAt: userData.createdAt,
    updatedAt: userData.updatedAt,
    location,
  };

// Add vehicle info only if the user is a driver
if (userData.userType === "driver") {
  const vehicleInstance = await Vehicle.findOne({ where: { driverId: userData.id } });
  if (vehicleInstance) {
    // Convert to plain object and cast to any to avoid TS errors
    const v: any = vehicleInstance.get({ plain: true });

    userResponse.vehicle = {
      id: v.id,
      type: v.type,
      licenseNo: v.licenseNo,
      createdAt: v.createdAt ?? null,
      updatedAt: v.updatedAt ?? null,
    };
  }
}


  return {
    success: true,
    message: "Login successful",
    token,
    user: userResponse,
  };
}


export async function resendOtp(keyType: "email" | "mobile", keyValue: string, name?: string) {
  const key = `${keyType}:${keyValue}`;
const normalizedKey =
  keyType === "email"
    ? `email:${keyValue.toLowerCase()}`
    : `mobile:${normalizeMobile(keyValue)}`;

const existingTemp = await TempRegistration.findOne({ where: { key: normalizedKey } });
if (!existingTemp) throw new Error("No pending registration found");

const otp = await generateOTP(normalizedKey, keyType);
  logger.info(`[Resend OTP] Key: ${key}, OTP: ${otp}`);

  if (keyType === "email") {
    await sgMail.send({
      to: keyValue,
      from: config.EMAIL_FROM!,
      subject: "Resend OTP - Verify your account",
      text: `Hello ${name || "User"}, your new OTP is ${otp}`,
    });
  } else {
    await sendSms(keyValue, `Your new OTP is ${otp}`);
  }

  return `New OTP sent to your ${keyType}`;
}

export async function refreshAccessToken(refreshToken: string) {
  try {
    interface JwtPayload {
      id?: string;       // for tokens created at login
      userId?: string;   // for tokens created at registration
      userType: string;
    }

    const decoded = jwt.verify(refreshToken, config.JWT_SECRET as string) as JwtPayload;

    // Normalize user ID field (support both 'id' and 'userId')
    const uid = decoded.userId || decoded.id;
    if (!uid) throw new Error("Invalid token payload");

    // Generate new access token
    const newAccessToken = jwt.sign(
      { userId: uid, userType: decoded.userType },
      config.JWT_SECRET as string,
      { expiresIn: "1d" }
    );

    return { accessToken: newAccessToken };
  } catch (error: any) {
    throw new Error("Invalid or expired refresh token");
  }
}



