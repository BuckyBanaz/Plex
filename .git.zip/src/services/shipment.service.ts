import Shipment from '../models/shipment.model';
import { estimateFromGoogle } from './estimation.service';
import { createPaymentIntent, capturePayment } from './payment.service';

export class ShipmentService {
  /**
   * Estimate shipment cost and distance using Google Distance API
   */
  async estimate(params: {
    originLat: number;
    originLng: number;
    destinationLat: number;
    destinationLng: number;
    weight: number;
  }) {
    return await estimateFromGoogle(params);
  }

  async createWithPayment(data: {
    userId: number;
    originLat: number;
    originLng: number;
    destinationLat: number;
    destinationLng: number;
    weight: number;
  }) {
    const { userId, originLat, originLng, destinationLat, destinationLng, weight } = data;

    // Get estimate from Google Distance API
    const estimate = await estimateFromGoogle({ originLat, originLng, destinationLat, destinationLng, weight });

    console.log("estimation ==========> ", estimate);

    // Create PayPal order using USD
    const paymentOrder = await createPaymentIntent(estimate.estimatedCostUSD, "USD");

    console.log("paymentOrder ==========> ", paymentOrder);

    // Create shipment record with PayPal orderId
    const shipment = await Shipment.create({
      userId,
      originLat,
      originLng,
      destinationLat,
      destinationLng,
      weight,
      distance: estimate.distanceKm,
      estimatedCost: estimate.estimatedCostINR, // keep original INR for your records
      status: 'pending',
      paymentStatus: 'unpaid',
      paypalOrderId: paymentOrder.id,
    });

    // Return shipment info and PayPal approval link
    const approveLink = paymentOrder.links.find((l: any) => l.rel === "approve")?.href;

    return { shipment, orderId: paymentOrder.id, approveLink, estimate };
  }

  async confirmPaymentAndMark(shipmentId: number, orderId: string, paymentStatus: 'paid' | 'unpaid') {
    const shipment = await Shipment.findByPk(shipmentId);
    if (!shipment) throw new Error('Shipment not found');

    if (paymentStatus === 'paid') {
      await capturePayment(orderId);
      shipment.status = 'awaiting_driver';
    }

    shipment.paymentStatus = paymentStatus;
    await shipment.save();

    return shipment;
  }
  /**
   * Assign driver and vehicle to shipment
   */
  async acceptShipment(shipmentId: number, driverId: number, vehicleId: number) {
    const shipment = await Shipment.findByPk(shipmentId);
    if (!shipment) throw new Error('Shipment not found');

    shipment.driverId = driverId;
    shipment.vehicleId = vehicleId;
    shipment.status = 'in_transit';
    await shipment.save();

    return shipment;
  }

  /**
   * Update current location of shipment
   */
  async updateLocation(shipmentId: number, loc: { lat: number; lng: number }) {
    const shipment = await Shipment.findByPk(shipmentId);
    if (!shipment) throw new Error('Shipment not found');

    shipment.currentLocation = loc;
    await shipment.save();

    return shipment.currentLocation;
  }

  /**
   * Create shipment directly without payment (admin use)
   */
  async createShipmentDirect(payload: any) {
    return await Shipment.create(payload);
  }

  /**
   * Get shipment by ID
   */
  async getShipmentById(id: number) {
    return await Shipment.findByPk(id);
  }

  /**
   * Get all shipments
   */
  async getAllShipments() {
    return await Shipment.findAll();
  }
}
