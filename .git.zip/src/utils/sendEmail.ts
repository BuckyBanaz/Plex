// import nodemailer from "nodemailer";

// const sendEmail = async (
//   to: string,
//   subject: string,
//   text: string
// ): Promise<void> => {
//   try {
//     const transporter = nodemailer.createTransport({
//       host: config.SMTP_HOST as string,
//       port: Number(config.SMTP_PORT),
//       secure: false, // true for 465, false for other ports
//       auth: {
//         user: config.SMTP_USER as string,
//         pass: config.SMTP_PASS as string,
//       },
//         tls: {
//     rejectUnauthorized: false, // allow self-signed certs if blocked
//   },
//     });

//     await transporter.sendMail({
//       from: `"Auth System" <${config.SMTP_USER}>`,
//       to,
//       subject,
//       text,
//     });

//     console.log(`Email sent to ${to}`);
//   } catch (error: any) {
    
//     console.error("Email sending failed:", error.message);
//   }
// };

// export default sendEmail;


import sgMail from "@sendgrid/mail";
import logger from "../utils/logger"; 
import fs from 'fs';

const config = JSON.parse(fs.readFileSync(__dirname + "/../config/config.json", "utf-8"));

export function initSendGrid() {
  if (!config.SENDGRID_API_KEY) {
    throw new Error("SENDGRID_API_KEY is not defined");
  }
  sgMail.setApiKey(config.SENDGRID_API_KEY);
}

export async function sendEmail(to: string, subject: string, text: string, html?: string) {
  try {
    await sgMail.send({
      to,
      from: config.EMAIL_FROM!,
      subject,
      text,
      html,
    });
    console.log(`Email sent to ${to}`);
  } catch (err: any) {
    console.error("SendGrid error:", err.response?.body || err.message);
    throw err;
  }
}

export default sgMail;



