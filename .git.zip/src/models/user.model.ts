import { Model, DataTypes, Optional, Sequelize } from "sequelize";
import type CorporateDetail from "./corporate.model";
import UserLocation from "./userLocation.model";
import UserLocationHistory from "./userLocationHistory.model";

export type UserType = "individual" | "corporate" | "guest" | "driver";

interface UserAttributes {
  id: number;
  name: string;
  email?: string | null;
  password?: string | null;
  userType: UserType;
  mobile?: string | null;
  isMobileVerified: boolean;
  isEmailVerified: boolean;
  deviceId: string;
  
  // Add aliases for associations
  currentLocation?: UserLocation; // for hasOne current location
  locationHistory?: UserLocationHistory[]; // for hasMany location history
  corporateDetail?: CorporateDetail;

  createdAt?: Date;
  updatedAt?: Date;
}

interface UserCreationAttributes
  extends Optional<
    UserAttributes,
    "id" | "email" | "password" | "mobile" | "isMobileVerified" | "isEmailVerified"
  > {}

export default class User
  extends Model<UserAttributes, UserCreationAttributes>
  implements UserAttributes
{
  public id!: number;
  public name!: string;
  public email!: string | null;
  public password!: string | null;
  public userType!: UserType;
  public mobile?: string | null;
  public isMobileVerified!: boolean;
  public isEmailVerified!: boolean;
  public deviceId!: string;

  // Association properties
  public currentLocation?: UserLocation;
  public locationHistory?: UserLocationHistory[];
  public corporateDetail?: CorporateDetail;

  public readonly createdAt!: Date;
  public readonly updatedAt!: Date;

  static initModel(sequelize: Sequelize) {
    User.init(
      {
        id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
        name: { type: DataTypes.STRING, allowNull: false },
        email: { type: DataTypes.STRING, allowNull: true },
        password: { type: DataTypes.STRING, allowNull: true },
        userType: {
          type: DataTypes.ENUM("individual", "corporate", "guest", "driver"),
          allowNull: false,
          defaultValue: "individual",
        },
        mobile: { type: DataTypes.STRING, allowNull: true },
        isMobileVerified: { type: DataTypes.BOOLEAN, defaultValue: false },
        isEmailVerified: { type: DataTypes.BOOLEAN, defaultValue: false },
        deviceId: { type: DataTypes.STRING, allowNull: true },
      },
      {
        tableName: "users",
        sequelize,
        timestamps: true,
      }
    );
  }
}
