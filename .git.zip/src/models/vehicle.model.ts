import { Model, DataTypes, Optional, Sequelize } from 'sequelize';
import User from './user.model';

interface VehicleAttributes {
  id: number;
  type: string;
  licenseNo: string;
  driverId: number;
}

interface VehicleCreationAttributes extends Optional<VehicleAttributes, 'id'> {}

export default class Vehicle
  extends Model<VehicleAttributes, VehicleCreationAttributes>
  implements VehicleAttributes
{
  public id!: number;
  public type!: string;
  public licenseNo!: string;
  public driverId!: number;

  // Association
  public driver?: User;

  static initModel(sequelize: Sequelize) {
    Vehicle.init(
      {
        id: {
          type: DataTypes.INTEGER,
          primaryKey: true,
          autoIncrement: true,
        },
        type: {
          type: DataTypes.STRING,
          allowNull: false,
        },
        licenseNo: {
          type: DataTypes.STRING,
          allowNull: false,
          unique: true,
        },
        driverId: {
          type: DataTypes.INTEGER,
          allowNull: false,
        },
      },
      {
        tableName: 'vehicles',
        sequelize,
        timestamps: true,
      }
    );
  }
}
