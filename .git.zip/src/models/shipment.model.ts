import { Model, DataTypes, Optional, Sequelize } from "sequelize";
import User from "./user.model";
import Vehicle from "./vehicle.model";

interface ShipmentAttributes {
  id: number;
  userId: number;
  driverId?: number | null;
  vehicleId?: number | null;
  originLat: number;
  originLng: number;
  destinationLat: number;
  destinationLng: number;
  weight: number;
  distance?: number | null;
  estimatedCost?: number | null;
  status: string; // pending, awaiting_driver, in_transit, delivered
  paymentStatus: string; // unpaid, paid
  paypalOrderId?: string | null; // new PayPal field
  currentLocation?: { lat: number; lng: number } | null;
  createdAt?: Date;
  updatedAt?: Date;
}

interface ShipmentCreationAttributes
  extends Optional<
    ShipmentAttributes,
    | "id"
    | "driverId"
    | "vehicleId"
    | "distance"
    | "estimatedCost"
    | "paypalOrderId"
    | "currentLocation"
  > {}

export default class Shipment
  extends Model<ShipmentAttributes, ShipmentCreationAttributes>
  implements ShipmentAttributes
{
  public id!: number;
  public userId!: number;
  public driverId?: number | null;
  public vehicleId?: number | null;
  public originLat!: number;
  public originLng!: number;
  public destinationLat!: number;
  public destinationLng!: number;
  public weight!: number;
  public distance?: number | null;
  public estimatedCost?: number | null;
  public status!: string;
  public paymentStatus!: string;
  public paypalOrderId?: string | null; // new field
  public currentLocation?: { lat: number; lng: number } | null;

  static initModel(sequelize: Sequelize) {
    Shipment.init(
      {
        id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
        userId: { type: DataTypes.INTEGER, allowNull: false },
        driverId: { type: DataTypes.INTEGER, allowNull: true },
        vehicleId: { type: DataTypes.INTEGER, allowNull: true },
        originLat: { type: DataTypes.FLOAT, allowNull: false },
        originLng: { type: DataTypes.FLOAT, allowNull: false },
        destinationLat: { type: DataTypes.FLOAT, allowNull: false },
        destinationLng: { type: DataTypes.FLOAT, allowNull: false },
        weight: { type: DataTypes.FLOAT, allowNull: false },
        distance: { type: DataTypes.FLOAT, allowNull: true },
        estimatedCost: { type: DataTypes.FLOAT, allowNull: true },
        status: {
          type: DataTypes.STRING,
          allowNull: false,
          defaultValue: "pending",
        },
        paymentStatus: {
          type: DataTypes.STRING,
          allowNull: false,
          defaultValue: "unpaid",
        },
        paypalOrderId: { type: DataTypes.STRING, allowNull: true }, // new field
        currentLocation: { type: DataTypes.JSONB, allowNull: true },
      },
      {
        tableName: "shipments",
        sequelize,
        timestamps: true,
      }
    );
  }

  static associate() {
    // Shipment belongs to User (the customer)
    Shipment.belongsTo(User, {
      foreignKey: "userId",
      as: "user",
    });

    // Shipment belongs to Driver (also a user)
    Shipment.belongsTo(User, {
      foreignKey: "driverId",
      as: "driver",
    });

    // Shipment belongs to Vehicle
    Shipment.belongsTo(Vehicle, {
      foreignKey: "vehicleId",
      as: "vehicle",
    });
  }
}
